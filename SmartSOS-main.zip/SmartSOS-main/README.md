# SmartSOS
IOT Based Smart Sos Device -supportive Code

Manual Code is in Arduino file
